using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CommandHandler : MonoBehaviour
{
    // Lets get the currentState

    GameObjectsManager gameObjectsManager;
    StateManager stateManager = StateManager.GetInstance();
    private PostGameData postGameData;

    public void Start()
    {
        if (stateManager != null)
        {
            IStateController currentState = stateManager.GetCurrentState();

        }

    }

    public void HandleInput(KeyCode input)
    {

        IStateController currentState = stateManager.GetCurrentState();
        gameObjectsManager = GameObjectsManager.Instance;

        if (input == KeyCode.Return)
        {

            if (currentState is (PreGameState or PauseState or ExtraTimeState or EndGameState))
            {
                stateManager.ChangeState(new InGameState());

            }
            else if (currentState is GoalState)
            {
                if (gameObjectsManager.gameController.extraTime)   // If we are in extra time, we go to endGame
                {
                    stateManager.ChangeState(new EndGameState());
                    gameObjectsManager.gameController.endGame = true;
                }
                else
                {
                    stateManager.ChangeState(new InGameState());
                }
            }
        }
        else if (input == KeyCode.P)
        {
            if (currentState is InGameState)
            {
                stateManager.ChangeState(new PauseState());
            }
        }

        else if (input == KeyCode.Escape)
        {
            if (currentState is PauseState)
            {
                if (!gameObjectsManager.gameController.endGame)
                {

                    stateManager.ChangeState(new InGameState());

                    gameObjectsManager.stopGame(false);
                    gameObjectsManager.gameController.exitGame = true;

                    SceneManager.LoadScene("MainMenu");
                }
            }
        }

    }
}