using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.U2D;


public interface IStateController
{
    void EnterState();
    void ExitState();
}


// We will now define each chold class of IGameState, defining the objects that will be used in each state


public class PreGameState : IStateController
{
    private GameObjectsManager gameObjectsManager;

    public PreGameState()
    {
        gameObjectsManager = GameObjectsManager.Instance;
    }

    public void EnterState()
    {

        // We set active the preGameMenu
        gameObjectsManager.preGameMenu.SetActive(true);
        gameObjectsManager.player1.SetActive(true);
        gameObjectsManager.player2.SetActive(true);

        gameObjectsManager.player1.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
        gameObjectsManager.player2.transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);

        if (PreGameData.GameMode == "pvp")
        {
            gameObjectsManager.player1.GetComponent<MovementPlayerAI>().enabled = false;
        }
        else
        {
            gameObjectsManager.player1.GetComponent<MovementPlayerLeft>().enabled = false;
        }


        gameObjectsManager.stopGame(true);

        // Lets check we enter here

        // Now we deactivate the rest of the menus

        gameObjectsManager.pauseMenu.SetActive(false);
        gameObjectsManager.extraTimeMenu.SetActive(false);
        gameObjectsManager.endGameMenu.SetActive(false);
        gameObjectsManager.trophy.SetActive(false);
        gameObjectsManager.scoreboard.SetActive(false);
        gameObjectsManager.goalAnimation.SetActive(false);
        gameObjectsManager.ball.SetActive(false);
    }

    public void ExitState()
    {
        // We activate the ball and the scoreboard

        gameObjectsManager.ball.SetActive(true);
        gameObjectsManager.scoreboard.SetActive(true);

        // We deactivate the preGameMenu

        gameObjectsManager.preGameMenu.SetActive(false);

        // We move the ball and the players to their initial positions

        gameObjectsManager.stopGame(false);
        gameObjectsManager.moveInitialPositions();

        // Ajustar escalas de los jugadores

        gameObjectsManager.player1.transform.localScale = new Vector3(0.8f, 0.8f, 0.8f);
        gameObjectsManager.player2.transform.localScale = new Vector3(0.8f, 0.8f, 0.8f);

    }

}


public class InGameState : IStateController
{
    private GameObjectsManager gameObjectsManager;

    public InGameState()
    {
        gameObjectsManager = GameObjectsManager.Instance;
    }

    public void EnterState()
    {
      
    }

    public void ExitState()
    {
        gameObjectsManager.stopGame(true);
    }
}


public class PauseState : IStateController
{
    private GameObjectsManager gameObjectsManager;

    public PauseState()
    {
        gameObjectsManager = GameObjectsManager.Instance;
    }

    public void EnterState()
    {
        gameObjectsManager.pauseMenu.SetActive(true);
    }

    public void ExitState()
    {
        gameObjectsManager.stopGame(false);
        gameObjectsManager.pauseMenu.SetActive(false);
    }
}



public class GoalState : IStateController
{
    private GameObjectsManager gameObjectsManager;
    private StateManager stateManager = StateManager.GetInstance();

    public GoalState()
    {
        gameObjectsManager = GameObjectsManager.Instance;
    }

    public void EnterState()
    {
        gameObjectsManager.goalAnimation.SetActive(true);

    }

    public void ExitState()
    {
        gameObjectsManager.stopGame(false);
        gameObjectsManager.goalAnimation.SetActive(false);
        gameObjectsManager.moveInitialPositions();
        
    }
}


public class ExtraTimeState : IStateController
{
    private GameObjectsManager gameObjectsManager;

    public ExtraTimeState()
    {
        gameObjectsManager = GameObjectsManager.Instance;
    }

    public void EnterState()
    {
        gameObjectsManager.extraTimeMenu.SetActive(true);
    }

    public void ExitState()
    {
        gameObjectsManager.stopGame(false);
        gameObjectsManager.extraTimeMenu.SetActive(false);
        gameObjectsManager.moveInitialPositions();

    }
}


public class EndGameState : IStateController
{
    private GameObjectsManager gameObjectsManager;
    private ScoreManager scoreManager;
    private PreGameData preGameData;
    private PostGameData postGameData;
    public Scene gameScene;
    public StateManager stateManager = StateManager.GetInstance();

    public EndGameState()
    {
        gameObjectsManager = GameObjectsManager.Instance;
        scoreManager = ScoreManager.Instance;
        
    }

    public void EnterState()
    {
        gameObjectsManager.endGameMenu.SetActive(true);
        gameObjectsManager.scoreboard.SetActive(false);
        gameObjectsManager.trophy.SetActive(true);
        gameObjectsManager.stopGame(true);
        scoreManager.UpdateScoreText(0);
        scoreManager.UpdateScoreText(1);

        if (scoreManager.score[0] > scoreManager.score[1])
        {
            gameObjectsManager.trophy.transform.position = new Vector3(-6.5f, -3f, -5f);
        }
        else
        {
            gameObjectsManager.trophy.transform.position = new Vector3(7.47f, -3f, -5f);
        }
        // We move the players to their new positions and change scale

        gameObjectsManager.player1.transform.position = new Vector3(-6.5f, -2.6f, -5f);
        gameObjectsManager.player2.transform.position = new Vector3(7.47f, -2.6f, -5f);
        gameObjectsManager.player1.transform.localScale = new Vector3(1f, 1f, 1f);
        gameObjectsManager.player2.transform.localScale = new Vector3(1f, 1f, 1f);

    }

    public void ExitState()
    {

        gameObjectsManager.stopGame(false);
        if (!gameObjectsManager.gameController.exitGame)
        {

            gameObjectsManager.gameController.exitGame = true;

            if (!gameObjectsManager.gameController.endGame)
            {
                CallToSelecInfo.ExecutionID = 3;
                CallToSelecInfo.ResultState = null;

                SceneManager.LoadScene("MainMenu");



            }

            // We check the game mode in PreGameData

            else
            {
                

                if (PreGameData.GameMode == "survival")
                {
                    // We go back to Execution ID 1

                    if (scoreManager.score[1] > scoreManager.score[0])
                    {
                        // Player has won
                        CallToSelecInfo.ExecutionID = 4;
                        CallToSelecInfo.ResultState = "victory";
                        SceneManager.LoadScene("PlayerSelectMenu");
                    }
                    else
                    {
                        CallToSelecInfo.ExecutionID = 3;
                        CallToSelecInfo.ResultState = "loss";
                        SceneManager.LoadScene("PlayerSelectMenu");
                    }


                }

                else if (PreGameData.GameMode == "arcade")
                {
                    // We go back to Execution ID 0

                    

                    if (scoreManager.score[1] > scoreManager.score[0])
                    {
                        // Player has won
                        CallToSelecInfo.ResultState = "victory";
                        CallToSelecInfo.ExecutionID = 3;

                    }
                    else
                    {
                        CallToSelecInfo.ResultState = "loss";
                        CallToSelecInfo.ExecutionID = 3;
                    }

                    SceneManager.LoadScene("PlayerSelectMenu");

                }

                else if (PreGameData.GameMode == "pvp")
                {
                    // We go back to Execution ID 2

                    CallToSelecInfo.ExecutionID = 3;
                    CallToSelecInfo.ResultState = null;
                    SceneManager.LoadScene("MainMenu");
                }



            }
        }
        
    }
}




